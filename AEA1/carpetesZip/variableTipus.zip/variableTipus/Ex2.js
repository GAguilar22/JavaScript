//Crea una constant PI amb el valor 3.1416 i calcula l’àrea d’un cercle amb radi 5. Mostra el resultat.

const PI = 3.1416;
let radi = 5;
let area = PI * (radi * radi);
console.log("L'area del cercle és: " + area);
