// Declara tres variables amb let: el teu nom, la teva edat i si tens carnet de conduir (true/false). Mostra-les a la consola.

let nom = "Gerard";
let edat = 29;
let carnet = true;

console.log(nom + " " + edat + " " + carnet);
