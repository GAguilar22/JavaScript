//Crea una variable granNumero amb un BigInt de més de 20 xifres i imprimeix el seu tipus amb typeof.
let granNum = 1234567890123456789012345678901234567890n;
console.log(granNum);
console.log(typeof granNum);
