//Escriu una expressió que retorni true només si una variable nota és més gran que 5 i més petita o igual que 10.
let nota = propmt("Intodueix un numero del 1 al 10");

if(nota >5 && nota >=10){
    console.log(true);
}else{
    console.log(false)
}