//Declara dues variables x = 5 i y = "5". Comprova amb == i amb === si són iguals. Explica la diferència.
let x = 5;
let y = "5";

console.log(x == t); //en aquest cas ens retorna un true perque tant x com y son 5, ja que només compara els valors

console.log(x === y); //ara ens retornarà false perque compara estem comparant tant el valor com el tipus i X és number i y és un string